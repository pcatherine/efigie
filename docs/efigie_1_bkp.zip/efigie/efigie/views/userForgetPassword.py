# #-*- coding: utf-8 -*-

from django.contrib.auth.decorators import login_required
from django.views.decorators.csrf import csrf_protect

from django.core.files.base import ContentFile
from django.core.files.storage import default_storage
from django.http import HttpResponse, HttpResponseRedirect
from django.shortcuts import render, redirect, render_to_response
from django.template import loader, Context, Template, RequestContext

from efigie.controller import EffigyParameters, EffigyCommunication
from efigie.controller.Encryption import RSA
from efigie.models import UserEfigie, Message, Key, Friend
from efigie.views import *

# CATHERINE mandar email
def userForgetPassword(request):
  if request.method == 'POST':
    username  = request.POST.get('username', '')

    if '@' in username:
      try: 
        user = User.objects.get(email=username)

        userEfigie = UserEfigie.objects.get(user_id=user.id)
        some_model_instance = userEfigie
        EmailConfirmation.objects.verify_email_for_object(
            email=user.email,
            content_object=some_model_instance,
            email_field_name='marketing_email'
        )

      except Exception,e:
        print e
        return render_to_response(EffigyParameters.USER_FORGET, 
          {'description': EffigyCommunication.USER_NOT_FOUND, 
          'alert': 'danger',
          'username' : username }, context_instance=RequestContext(request))
    
    else:
      try: 
        user = User.objects.get(username=username)

        userEfigie = UserEfigie.objects.get(user_id=user.id)
        some_model_instance = userEfigie
        EmailConfirmation.objects.verify_email_for_object(
            email=user.email,
            content_object=some_model_instance,
            email_field_name='marketing_email'
        )

      except Exception,e:
        return render_to_response(EffigyParameters.USER_FORGET, 
          {'description': EffigyCommunication.USER_NOT_FOUND, 
          'alert': 'danger',
          'username' : username }, context_instance=RequestContext(request))
      
    return render_to_response(EffigyParameters.USER_LOGIN, 
      {'description': EffigyCommunication.USER_FORGET_PASSWORD, 
       'alert': 'success'}, context_instance=RequestContext(request))

  return render(request, EffigyParameters.USER_FORGET)