#-*- coding: utf-8 -*-
from django.contrib.auth.decorators import login_required
from django.conf import settings
from django.contrib.auth import authenticate, login, logout
from django.core.context_processors import csrf
from django.core.files.base import ContentFile
from django.core.files.storage import default_storage
from django.core.mail import send_mail
from django.core.urlresolvers import reverse

from django.db import models
from django.http import HttpResponse, HttpResponseRedirect
from django.shortcuts import render, redirect, render_to_response
from django.template import loader, Context, Template, RequestContext
from django.utils.safestring import mark_safe
from django.utils import translation


# from efigie.controller.Encryption import RSA
# from efigie.controller.Util import *
from efigie.controller import EffigyParameters, EffigyCommunication, GoogleAPI
from email_confirm_la.models import EmailConfirmation


from efigie.models import *

import qrcode
from qrcode.image.pure import PymagingImage

import PIL
from PIL import ImageFont, Image, ImageDraw

import requests
import re
import urllib2
import os

import gettext 
import locale
import os
from efigie.views import *

def userNew(request):
  if request.method == 'POST':
    firstName = request.POST.get('firstName', '')
    lastName = request.POST.get('lastName', '')
    username = request.POST.get('username', '')
    email = request.POST.get('email', '')
    password = request.POST.get('password', '')
    rePassword = request.POST.get('re-password', '')

    descriptionErr = ''
    inputEmpty = []

    if firstName  == '': 
      inputEmpty.append(EffigyCommunication.NAME)
    if username == '':
      inputEmpty.append('Username')
    if email == '':
      inputEmpty.append('E-mail')
    if password == '':
      inputEmpty.append(EffigyCommunication.PASSWORD)
    if rePassword == '':
      inputEmpty.append(EffigyCommunication.CONFIRM + ' ' + EffigyCommunication.PASSWORD)

    if len(inputEmpty) == 1:
      descriptionErr += inputEmpty[0] 
      descriptionErr += ' ' + EffigyCommunication.IS_BLANK 

    elif len(inputEmpty) > 1:
      for i in xrange (len(inputEmpty) - 1):
        descriptionErr += inputEmpty[i]
        if i != len(inputEmpty) - 2:
          descriptionErr += ', '
      descriptionErr += ' ' + EffigyCommunication.AND + ' '
      descriptionErr += inputEmpty[len(inputEmpty)-1] 
      descriptionErr += ' ' + EffigyCommunication.ARE_BLANK 

    if descriptionErr != '':
      return userError(request, EffigyParameters.USER_NEW, descriptionErr, firstName, lastName, username, email)
    
    try:
      userOb = User.objects.get(email=email)
      return userError(request,EffigyParameters.USER_NEW, 'E-mail' + ' ' + EffigyCommunication.USER_ALREADY_REGISTER, firstName, lastName, username, email)

    except User.DoesNotExist:
      try:
        userOb = User.objects.get(username=username)
        return userError(request,EffigyParameters.USER_NEW, 'Username' + ' ' + EffigyCommunication.USER_ALREADY_REGISTER, firstName, lastName, username, email)
      except:
        if password != rePassword:
          return userError(request,EffigyParameters.USER_NEW, EffigyCommunication.PASSWORD_NOT_MATCH, firstName, lastName, username, email)

        user = User.objects.create_user(username, email, password)
        user.first_name = firstName
        user.last_name = lastName
        user.save()

        userLogin = authenticate(username=username, password=password)

        # login(request, userLogin)

        userEfigie = UserEfigie.objects.create(user = user, settings = '111000000010110000', googleAuthenticator = '', pinUsername = '', pintEmail = '', pinSenha = '' )
        userEfigie.save()

        # some_model_instance = User.objects.get(username=username).id

        some_model_instance = userEfigie
        EmailConfirmation.objects.verify_email_for_object(
            email=email,
            content_object=some_model_instance,
            email_field_name='customer_support_email'
        )

        return efigie.views.userLogin(request, EffigyParameters.ALERT_INFO, EffigyCommunication.USER_CONFIRMATION, username) 

  return render(request, EffigyParameters.USER_NEW)     




def userError(request,html, description, firstName, lastName, username, email):    
  return render_to_response(html, {'description': description,    
    'alert'    : 'danger',    
    'firstName': firstName ,    
    'lastName' : lastName,    
    'username' : username,    
    'email'    : email }, context_instance=RequestContext(request))