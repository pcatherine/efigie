#!/usr/bin/python
#-*- coding: utf-8 -*-
#OKAY
__author__ = "Paolla Catherine"
__copyright__ = "Copyright 2015-2016, Efigie"
__credits__ = ["Paolla Catherine"]
__version__ = "1.0.0"
__email__ = "paollacath@gmail.com"
__status__ = "Production"

from django.contrib.auth.decorators import login_required
from django.shortcuts import render

from efigie.controller import EffigyParameters, EffigyCommunication
from efigie.models import UserEfigie, Message, Key, Friend
from efigie.views import *
#AGARD
@login_required
def index(request):
  return render(request, EffigyParameters.INDEX)