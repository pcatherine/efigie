#!/usr/bin/python
#-*- coding: utf-8 -*-

__author__ = "Paolla Catherine"
__copyright__ = "Copyright 2015-2016, Efigie"
__credits__ = ["Paolla Catherine"]
__version__ = "1.0.0"
__email__ = "paollacath@gmail.com"
__status__ = "Production"

from django.contrib.auth.decorators import login_required

from django.shortcuts import render, redirect, render_to_response
from django.template import loader, Context, Template, RequestContext

from efigie.controller import EffigyParameters, EffigyCommunication, GoogleAPI
from efigie.models import UserEfigie, Message, Key, Friend
from efigie.views import *

#CATHERINE verificar o tamanho correto das coisas
@login_required
def imageSearch(request, alert='', description='', message=''):
  imgTheme = request.POST.get('imgTheme', '')
  if imgTheme != '':
    res = GoogleAPI.customSearch(imgTheme)

    imgList = []
    for result in res['items']:
      imgList.append({'idx':res['items'].index(result), 'url':result['link']})

    request.session['msgImgList'] = imgList
    request.session['msgWrite'] = 'Google'

    return render_to_response(EffigyParameters.IMAGE_SEARCH, 
    {'imgList': imgList}, context_instance=RequestContext(request))

  return render_to_response(EffigyParameters.IMAGE_SEARCH, 
    {'description': description,
    'alert': alert }, context_instance=RequestContext(request))