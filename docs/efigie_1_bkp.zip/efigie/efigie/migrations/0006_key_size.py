# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('efigie', '0005_key_identifier'),
    ]

    operations = [
        migrations.AddField(
            model_name='key',
            name='size',
            field=models.IntegerField(default=0),
            preserve_default=False,
        ),
    ]
