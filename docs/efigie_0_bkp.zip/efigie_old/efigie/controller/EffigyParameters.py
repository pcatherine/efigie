# template_name by render
IMAGE_SEARCH = 'image_search.html'

INDEX = 'index.html'

KEY_EDIT = 'key_edit.html'
KEY_IMPORT = 'key_import.html'
KEY_LIST = 'key_list.html'
KEY_NEW = 'key_new.html'
KEY_SHOW = 'key_show.html'

MESSAGE_READ = 'message_read.html'
MESSAGE_SETTINGS = 'message_settings.html'
MESSAGE_WRITE = 'message_write.html'
MESSAGE_WRITE_OK = 'message_write_ok.html'

USER_AUTHENTICATOR = 'user_authenticator.html'
USER_EDIT = 'user_edit.html'
USER_FORGET = 'user_forget.html'
USER_FORGET_PASSWORD = 'user_forget_password.html'
USER_LOGIN = 'user_login.html'
USER_LOGIN_AUTHENTICATOR = 'user_login_authenticator.html'
USER_NEW = 'user_new.html'
USER_PASSWORD = 'user_password.html'
USER_SETTINGS = 'user_settings.html'

# Types of Alerts by _alert.html
ALERT_INFO    = 'info' 
ALERT_SUCCESS = 'success' 
ALERT_WARNING = 'warning' 
ALERT_DANGER  = 'danger' 