#-*- coding: utf-8 -*-
import gettext 
import locale

nameFileTraduction ='django'# nome do arquivo de traducao 
namefolderLocationFileTraduction ='locale'# localizacao inicial do arquivo de traducao, a localizacao completa é locale\pt_BR\LC_MESSAGES 
language = gettext.translation(nameFileTraduction, namefolderLocationFileTraduction, languages=['pt']) 
language.install() # instalacao da Linguagem requerida 
_ = language.ugettext # renomeando o gettext para _ 


IMAGE_BLANK = _('A imagem esta em branco.')

IDENTIFIER_EXIST = _('Identificador ja cadastrado.')
IDENTIFIER_BLANK = _('Identificador esta em branco.')

MESSAGE_BLANK      = _('A mensagem esta em branco.')
MESSAGE_BLANK_SIZE = _('A quantidade de vezes que a mensagem pode ser lida deve ser um numero maior que 0 ou deixada em branco')
MESSAGE_NOT_FOUND  = _('Nenhuma mensagem encontrada')
MESSAGE_LIMIT      = _('A mensagem ja excedeu o numero maximo de vezes que poderia ser lida')
MESSAGE_WRITE      = _('A mensagem foi gerada com sucesso.')
MESSAGE_SEARCH     = _('Como nenhuma imagem foi selecionada, busque uma abaixo')

KEY = _('A chave: ')
KEY_DELETE     = _(' foi excluida com sucesso.')
KEY_DELETE_TITLE = _('Deletar a chave: ')
KEY_DELETE_DESCRIPTION = _('Voce tem certeza que deseja deletar a chave: ')
KEY_DELETE_BUTTON = _('Deletar')
KEY_NOT_DELETE = _(' nao pode ser excluida.')
KEY_IMPORT     = _(' foi importada com sucesso.') 
KEY_NOT_IMPORT = _(' nao pode ser importada.') 
KEY_NEW        = _(' foi criada com sucesso.') 
KEY_NOT_EXPORT = _(' nao pode ser exportada.') 
KEY_EDIT       = _(' nao pode ser editada.') 
KEY_NOT_EDIT   = _(' nao pode ser alterada.') 
KEY_NOT_SHOW   = _(' escolhida nao pode ser exibida.')
KEY_NOT_FOUND  = _('Nenhuma chave encontrada.')
KEY_BLANK_SIZE = _('Tamanho da chave nao esta selecionado.')



USER_ALREADY_REGISTER = _('Usuario ja cadastrado.')
USER_CONFIRMATION     = _('Uma confirmacao foi enviada para o seu endereco de e-mail, para realizar o login e necessario realizar a confirmacao antes.')
USER_CONFIRMATION_SUCCESS = _('Confirmacao de e-mail realizada com sucesso.')
USER_CONFIRMATION_DANGER = _('Confirmacao de e-mail nao encontrada.')
USER_CONFIRMATION_EXPIRED = _('Esta confirmacao de e-mail expirou.')
USER_NOT_DELETE       = _('Usuario nao pode ser excluido.')
USER_DELETE           = _('Usuario excluido com sucesso.')
USER_DELETE_TITLE       = _('Deletar seu usuario')
USER_DELETE_DESCRIPTION = _('Voce tem certeza que deseja deletar a sua conta de usuario? Todas as chaves relacionadas somentes a voce tambem serao apagadas')
USER_DELETE_BUTTON      = _('Deletar')
USER_FORGET_PASSWORD = _('Enviamos um e-mail com instrucoes.')
USER_LOGOUT           = _('Logout realizado com sucesso.')
USER_NOT_FOUND        = _('Usuario nao encontrado')
USER_INVALID          = _('Username/e-mail ou senha invalidos')
USER_NOT_EDIT         = _('Usuario nao pode ser alterado.')

PASSWORD_EDIT = _('Senha alterada com sucesso.')
PASSWORD_NOT_MATCH = _('Senhas nao correspondentes.')
PASSWORD_INVALID   = _('Senha atual invalida')

TOKEN_CREATE     = _('Segunda verificacao de login ativada com sucesso.')
TOKEN_NOT_CREATE = _('Segunda verificacao de login desativada com sucesso.')
TOKEN_INVALID    = _('Codigo invalido.')