# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('efigie', '0009_remove_userefigie_confirmation'),
    ]

    operations = [
        migrations.AddField(
            model_name='userefigie',
            name='customer_support_email',
            field=models.EmailField(max_length=255, null=True, blank=True),
        ),
        migrations.AddField(
            model_name='userefigie',
            name='marketing_email',
            field=models.EmailField(max_length=255, null=True, blank=True),
        ),
    ]
