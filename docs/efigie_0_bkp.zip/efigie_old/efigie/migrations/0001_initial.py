# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations
from django.conf import settings


class Migration(migrations.Migration):

  dependencies = [
    migrations.swappable_dependency(settings.AUTH_USER_MODEL),
  ]

  operations = [
    migrations.CreateModel(
      name='Key',
      fields=[
        ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
        ('publicKey', models.TextField()),
        ('privateKey', models.TextField()),
        ('user', models.ForeignKey(to=settings.AUTH_USER_MODEL)),
      ],
    ),
    migrations.CreateModel(
      name='Message',
      fields=[
        ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
        ('countRead', models.IntegerField()),
      ],
    ),
    migrations.CreateModel(
      name='UserEfigie',
      fields=[
        ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
        ('settings', models.CharField(max_length=15)),
        ('googleAuthenticator', models.CharField(max_length=16)),
        ('pinUsername', models.CharField(max_length=255)),
        ('pintEmail', models.CharField(max_length=255)),
        ('pinSenha', models.CharField(max_length=255)),
        ('user', models.ForeignKey(to=settings.AUTH_USER_MODEL)),
      ],
    ),
  ]
