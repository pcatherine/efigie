"""efigie URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/1.8/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  url(r'^$', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  url(r'^$', Home.as_view(), name='home')
Including another URLconf
    1. Add an import:  from blog import urls as blog_urls
    2. Add a URL to urlpatterns:  url(r'^blog/', include(blog_urls))
"""
import os
from django.conf.urls import include, url
from django.contrib import admin

from django.conf import settings
from django.conf.urls.static import static

import efigie.views as views


urlpatterns = [
  url(r'^email_confirmation/key/(?P<confirmation_key>\w+)/$', views.userEmailConfirmation, name='userEmailConfirmation'),
  
  url(r'^email_confirmation/', include('email_confirm_la.urls', namespace='email_confirm_la')),

  url(r'^$', views.index, name='index'),

  url(r'^user/new/$', views.userNew, name='userNew'),
  url(r'^user/edit/$', views.userEdit, name='userEdit'),
  url(r'^user/delete/$', views.userDelete, name='userDelete'),
  url(r'^user/password/$', views.userPassword, name='userPassword'),
  url(r'^user/settings/$', views.userSettings, name='userSettings'),

  url(r'^login/$', views.userLogin, name='userLogin'),
  url(r'^login/authenticator/$', views.userLoginAuthenticator, name='userLoginAuthenticator'),
  url(r'^logout/$', views.userLogout, name='userLogout'),
  url(r'^forget/$', views.userForgetPassword, name='userForgetPassword'),

  # KEY
  url(r'^key/list/$', views.keyList, name='keyList'),
  url(r'^key/new/$', views.keyNew, name='keyNew'),
  url(r'^key/import/$', views.keyImport, name='keyImport'),
  url(r'^key/(?P<keyId>[0-9]+)/show/$', views.keyShow, name='keyShow'),
  url(r'^key/(?P<keyId>[0-9]+)/export/$', views.keyExport, name='keyExport'),
  url(r'^key/(?P<keyId>[0-9]+)/edit/$', views.keyEdit, name='keyEdit'),
  url(r'^key/(?P<keyId>[0-9]+)/delete/$', views.keyDelete, name='keyDelete'),

  #MESSAGE
  url(r'^message/read/$', views.messageRead, name='messageRead'),
  url(r'^message/write/$', views.messageWrite, name='messageWrite'),
  url(r'^message/write/search/$', views.imageSearch, name='imageSearch'),
  url(r'^message/write/(?P<image>[\w-]+)/$', views.messageSet, name='messageSet'),
  url(r'^message/settings/$', views.messageSettings, name='messageSettings'),

  url(r'^user/authenticator/$', views.userAuthenticator, name='userAuthenticator'),
  # url(r'^user/authenticator2/(?P<token>[\w-]+)/$', views.userAuthenticator2, name='userAuthenticator2'),

 
  # url(r'^teste2/(?P<imgURL>[\w-]+)/$', views.teste2, name='teste2'),

  

  # CATHERINE ERRADO
  


  # url(r'^users/pintrest/', views.userPinterest, name='userPintrest'),

  
  # url(r'^users/authenticator3/', views.userAuthenticatorDeac2, name='userAuthenticatorDeac'),
  # url(r'^users/authenticator4/', views.userAuthenticatorDeac2, name='userAuthenticatorDeac2'),



  # url(r'^google', views.searchingGoogleImage, name='searchingGoogleImage'),


  url(r'^admin/', include(admin.site.urls)),
  
  # # ex: /polls/
    # # ex: /polls/5/
    # url(r'^detail/$', views.detail, name='detail'),
    # # ex: /polls/5/results/
    # url(r'^(?P<question_id>[0-9]+)/results/$', views.results, name='results'),
    # # ex: /polls/5/vote/
    # url(r'^(?P<question_id>[0-9]+)/vote/$', views.vote, name='vote'),
] + static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)

