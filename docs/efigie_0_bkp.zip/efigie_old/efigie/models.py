from django.db import models
from django.contrib.auth.models import User
from email_confirm_la.models import EmailConfirmation
from django.contrib.contenttypes.generic import GenericRelation

class UserEfigie(models.Model):
  user = models.ForeignKey(User)
  settings = models.CharField(max_length=20)
  googleAuthenticator = models.CharField(max_length=30)
  pinUsername = models.CharField(max_length=255)
  pintEmail = models.CharField(max_length=255)
  pinSenha = models.CharField(max_length=255)

  customer_support_email = models.EmailField(max_length=255, null=True, blank=True)
  marketing_email = models.EmailField(max_length=255, null=True, blank=True)
  email_confirmations = GenericRelation('email_confirm_la.EmailConfirmation', content_type_field='content_type', object_id_field='object_id')


class Message(models.Model):
  countRead = models.IntegerField()


class Key(models.Model):
  user = models.ForeignKey(User)
  identifier = models.CharField(max_length=255)
  size = models.IntegerField()
  publicKey  = models.TextField()
  privateKey = models.TextField()


class Friend(models.Model):
  user1 = models.ForeignKey(User, unique=False, related_name='user1')
  user2 = models.ForeignKey(User, unique=False, related_name='user2')
  key = models.ForeignKey(Key)