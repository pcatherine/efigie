#-*- coding: utf-8 -*-
from django.contrib.auth.decorators import login_required
from django.views.decorators.csrf import csrf_protect

from django.core.files.base import ContentFile
from django.core.files.storage import default_storage
from django.http import HttpResponse, HttpResponseRedirect
from django.shortcuts import render, redirect, render_to_response
from django.template import loader, Context, Template, RequestContext

from efigie.controller import EffigyParameters, EffigyCommunication
from efigie.controller.Encryption import RSA
from efigie.models import UserEfigie, Message, Key, Friend
from efigie.views import *

@csrf_protect
@login_required
def keyNew(request):
  if request.method == 'POST':
    sizeKey   = request.POST.get('key', '')
    identifier = request.POST.get('identifier', '')

    if (sizeKey == '' ):
      return render_to_response(EffigyParameters.KEY_NEW,  
        {'description': EffigyCommunication.KEY_BLANK_SIZE, 
        'alert': 'danger',
        'identifier': identifier,
        'size': sizeKey}, context_instance=RequestContext(request))

    elif (identifier == '' ):
      return render_to_response(EffigyParameters.KEY_NEW,  
        {'description': EffigyCommunication.IDENTIFIER_BLANK, 
        'alert': 'danger',
        'identifier': identifier,
        'size': sizeKey}, context_instance=RequestContext(request))

    else:
      privateKey, publicKey = RSA.generate(int(sizeKey))
      try: 
        keyVerify = Key.objects.get(identifier=identifier)
        return render_to_response(EffigyParameters.KEY_NEW,  
          {'description': EffigyCommunication.IDENTIFIER_EXIST, 
          'alert': EffigyParameters.ALERT_DANGER,
          'identifier': identifier,
          'size': sizeKey}, context_instance=RequestContext(request))

      except Key.DoesNotExist:
        key = Key.objects.create(user = request.user, identifier = identifier, size = sizeKey, privateKey = privateKey, publicKey = publicKey)
        key.save()
        return keyList(request, EffigyParameters.ALERT_SUCCESS,  EffigyCommunication.KEY+"<b>"+ identifier + "</b>"+ EffigyCommunication.KEY_NEW)

  return render(request, EffigyParameters.KEY_NEW)