#!/usr/bin/python
#-*- coding: utf-8 -*-

__author__ = "Paolla Catherine"
__copyright__ = "Copyright 2015-2016, Efigie"
__credits__ = ["Paolla Catherine"]
__version__ = "1.0.0"
__maintainer__ = "Paolla Catherine"
__email__ = "paollacath@gmail.com"
__status__ = "Production"

from django.contrib.auth.decorators import login_required
from django.contrib.auth import logout

from efigie.controller import EffigyParameters, EffigyCommunication
from efigie.models import UserEfigie, Message, Key, Friend
from efigie.views import *

@login_required
def userLogout(request):
  logout(request)
  return efigie.views.userLogin(request, EffigyParameters.ALERT_SUCCESS, EffigyCommunication.USER_LOGOUT) 