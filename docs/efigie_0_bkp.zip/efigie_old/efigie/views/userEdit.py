#-*- coding: utf-8 -*-
from django.contrib.auth.decorators import login_required
from django.conf import settings
from django.contrib.auth import authenticate, login, logout
from django.core.context_processors import csrf
from django.core.files.base import ContentFile
from django.core.files.storage import default_storage
from django.core.mail import send_mail
from django.core.urlresolvers import reverse

from django.db import models
from django.http import HttpResponse, HttpResponseRedirect
from django.shortcuts import render, redirect, render_to_response
from django.template import loader, Context, Template, RequestContext
from django.utils.safestring import mark_safe
from django.utils import translation

# from efigie.controller.Encryption import RSA
# from efigie.controller.Util import *
from efigie.controller import EffigyParameters, EffigyCommunication, GoogleAPI


from efigie.models import *

import qrcode
from qrcode.image.pure import PymagingImage

import PIL
from PIL import ImageFont, Image, ImageDraw

import requests
import re
import urllib2
import os

import gettext 
import locale
import os
from efigie.views import *

@login_required
def userEdit(request):
  c = {}
  c.update(csrf(request))
  if request.method == 'POST':
    user = User.objects.get(username=request.user.username)

    firstName = request.POST.get('firstName', '')
    lastName = request.POST.get('lastName', '')
    username = request.POST.get('username', '')
    email = request.POST.get('email', '')

    if request.user is not None:
      user.first_name = (user.first_name, firstName) [firstName != '']
      user.last_name = (user.last_name, lastName) [lastName != '']
      if username != '' and email != '':
        try:
          userOb = User.objects.get(email=email)
          if userOb.id != user.id:
            return render_to_response(EffigyParameters.USER_EDIT, 
              {'alert': 'danger',
              'description': 'E-mail' + EffigyCommunication.SPACE + EffigyCommunication.ALREADY_REGISTER,
              'user': request.user }, context_instance=RequestContext(request))
        except User.DoesNotExist:
          try:
            userOb = User.objects.get(username=username)
            if userOb.id != user.id:
              return render_to_response(EffigyParameters.USER_EDIT, 
                {'alert': 'danger',
                'description': 'Username' + EffigyCommunication.SPACE + EffigyCommunication.ALREADY_REGISTER,
                'user': request.user }, context_instance=RequestContext(request))
          except:
            user.username = username
            user.email = email
        user.save()
    else:
      return render_to_response(EffigyParameters.USER_EDIT, 
        {'alert': 'danger',
        'description': EffigyCommunication.USER_NOT_EDIT,
        'user': request.user }, context_instance=RequestContext(request))

    return redirect('/user/settings/')

  if request.user is not None:
    return render_to_response(EffigyParameters.USER_EDIT, 
      {'user': request.user }, context_instance=RequestContext(request))