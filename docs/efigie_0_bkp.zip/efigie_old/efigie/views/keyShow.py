#!/usr/bin/python
#-*- coding: utf-8 -*-

__author__ = "Paolla Catherine"
__copyright__ = "Copyright 2015-2016, Efigie"
__credits__ = ["Paolla Catherine"]
__version__ = "1.0.0"
__maintainer__ = "Paolla Catherine"
__email__ = "paollacath@gmail.com"
__status__ = "Production"

from django.contrib.auth.decorators import login_required
from django.shortcuts import render, redirect, render_to_response
from django.template import loader, Context, Template, RequestContext

from efigie.controller import EffigyParameters, EffigyCommunication
from efigie.models import UserEfigie, Message, Key, Friend
from efigie.views import *

@login_required
def keyShow(request, keyId):
  try:
    key = Key.objects.get(id = keyId)
    return render_to_response(EffigyParameters.KEY_SHOW,  
      {'key': key,
      'confirmTitle': EffigyCommunication.KEY_DELETE_TITLE, 
      'confirmDescription' : EffigyCommunication.KEY_DELETE_DESCRIPTION, 
      'confirmButton':EffigyCommunication.KEY_DELETE_BUTTON}, context_instance=RequestContext(request))

  except Exception, e:
    # print e, key
    return keyList(request, EffigyParameters.ALERT_DANGER, EffigyCommunication.KEY_NOT_SHOW)