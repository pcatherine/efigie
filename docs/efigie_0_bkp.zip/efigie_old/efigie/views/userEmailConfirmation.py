from django.shortcuts import render

from email_confirm_la.models import EmailConfirmation
import efigie.config
from efigie.controller import EffigyParameters, EffigyCommunication


def userEmailConfirmation(request, confirmation_key, newPassword=None):
  try:
    email_confirmation = EmailConfirmation.objects.get(confirmation_key=confirmation_key)
  except EmailConfirmation.DoesNotExist:
    return efigie.views.userLogin(request, EffigyParameters.ALERT_DANGER, EffigyCommunication.USER_CONFIRMATION_DANGER)
    # return render(request, 'email_confirm_la/email_confirmation_fail.html')

  context = dict(efigie.config.EMAIL_CONFIRM_LA_TEMPLATE_CONTEXT)
  context['email_confirmation'] = email_confirmation

  try:
    email_confirmation.confirm()
    email_confirmation.clean()
  except EmailConfirmation.ExpiredError:
    return efigie.views.userLogin(request, EffigyParameters.ALERT_SUCCESS, '%s:%s' % (EffigyCommunication.USER_CONFIRMATION_EXPIRED, email_confirmation))
    # return render(request, 'email_confirm_la/email_confirmation_expiration.html', context)

  if efigie.config.EMAIL_CONFIRM_LA_AUTOLOGIN and isinstance(email_confirmation.content_object, User):
    email_confirmation.content_object.backend = 'django.contrib.auth.backends.ModelBackend'
    login(request, email_confirmation.content_object)

  return efigie.views.userLogin(request, EffigyParameters.ALERT_SUCCESS, '%s:%s' % (EffigyCommunication.USER_CONFIRMATION_SUCCESS, email_confirmation)) 