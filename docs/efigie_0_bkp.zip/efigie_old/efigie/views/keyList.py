#!/usr/bin/python
#-*- coding: utf-8 -*-

__author__ = "Paolla Catherine"
__copyright__ = "Copyright 2015-2016, Efigie"
__credits__ = ["Paolla Catherine"]
__version__ = "1.0.0"
__maintainer__ = "Paolla Catherine"
__email__ = "paollacath@gmail.com"
__status__ = "Production"

from django.contrib.auth.decorators import login_required
from django.shortcuts import render, redirect, render_to_response
from django.template import RequestContext

from efigie.controller import EffigyParameters, EffigyCommunication, Util
from efigie.models import UserEfigie, Message, Key, Friend
from efigie.views import *
#OKAY
@login_required
def keyList(request, alert='', description=''):
  keyList = Key.objects.filter(user = request.user).order_by('identifier')
  if len(keyList) > 0:
    return render_to_response(EffigyParameters.KEY_LIST, 
      {'keyList': keyList, 
      'alert': alert,
      'description': description, 
      'confirmTitle': EffigyCommunication.KEY_DELETE_TITLE, 
      'confirmDescription' : EffigyCommunication.KEY_DELETE_DESCRIPTION, 
      'confirmButton':EffigyCommunication.KEY_DELETE_BUTTON}, context_instance=RequestContext(request))

  return render_to_response(EffigyParameters.KEY_LIST, 
    {'alert': alert,
    'description': description, 
    'confirmTitle': EffigyCommunication.KEY_DELETE_TITLE, 
    'confirmDescription' : EffigyCommunication.KEY_DELETE_DESCRIPTION, 
    'confirmButton':EffigyCommunication.KEY_DELETE_BUTTON}, context_instance=RequestContext(request))