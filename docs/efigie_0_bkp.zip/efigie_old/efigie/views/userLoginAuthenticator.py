#-*- coding: utf-8 -*-
from django.contrib.auth.decorators import login_required
from django.conf import settings
from django.contrib.auth import authenticate, login, logout
from django.core.context_processors import csrf
from django.core.files.base import ContentFile
from django.core.files.storage import default_storage
from django.core.mail import send_mail
from django.core.urlresolvers import reverse

from django.db import models
from django.http import HttpResponse, HttpResponseRedirect
from django.shortcuts import render, redirect, render_to_response
from django.template import loader, Context, Template, RequestContext
from django.utils.safestring import mark_safe
from django.utils import translation


from efigie.controller import EffigyParameters, EffigyCommunication, GoogleAPI


from efigie.models import *

import qrcode
from qrcode.image.pure import PymagingImage

import PIL
from PIL import ImageFont, Image, ImageDraw

import requests
import re
import urllib2
import os

import gettext 
import locale
import os
from efigie.views import *

def userLoginAuthenticator(request):
  if request.method == 'POST':
    code = request.POST.get('google', '')
    if 'user' in request.session:
      username = request.session['user']
      
      del request.session['user']

      UserOb = User.objects.get(username = username)
      userEfigie = UserEfigie.objects.get(user = UserOb)
      if(GoogleAPI.authenticatorVerify(userEfigie.googleAuthenticator, code) == True):   
        UserOb.backend = 'django.contrib.auth.backends.ModelBackend'
        login(request, UserOb)
        return redirect("/")      
      
      else:
        return render_to_response(EffigyParameters.USER_LOGIN_AUTHENTICATOR, 
        {'alert': 'danger',
        'description': EffigyCommunication.TOKEN_INVALID }, context_instance=RequestContext(request))
    
    else:
      return render_to_response(EffigyParameters.USER_LOGIN_AUTHENTICATOR, 
        {'alert': 'danger',
        'description': EffigyCommunication.USER_NOT_FOUND }, context_instance=RequestContext(request))

  return render_to_response(EffigyParameters.USER_LOGIN_AUTHENTICATOR, 
    {'alert': 'info',
    'description': 'Como voce ativou a verificacao em duas etapas, e preciso confirmar a sua identidade. Insira o codigo gerado por seu aplicativo autenticador' }, context_instance=RequestContext(request))
