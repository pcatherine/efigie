#!/usr/bin/python
#-*- coding: utf-8 -*-

__author__ = "Paolla Catherine"
__copyright__ = "Copyright 2015-2016, Efigie"
__credits__ = ["Paolla Catherine"]
__version__ = "1.0.0"
__email__ = "paollacath@gmail.com"
__status__ = "Production"

from django.contrib.auth.decorators import login_required
from django.contrib.auth import authenticate, login, logout
from django.db import models
from django.http import HttpResponse, HttpResponseRedirect
from django.shortcuts import render, redirect, render_to_response
from django.template import loader, Context, Template, RequestContext

from efigie.controller import EffigyParameters, EffigyCommunication, GoogleAPI
from efigie.models import UserEfigie, Message, Key, Friend
from efigie.views import *


#CATHERINE enviar email
@login_required
def userPassword(request, alert='', description=''):
  if request.method == 'POST':
    password = request.POST.get('password', '')
    newPassword = request.POST.get('newpassword','')
    rePassword = request.POST.get('re-password','')
    
    if request.user.check_password(password):
      user = User.objects.get(username=request.user.username)
      if user is not None:
        if newPassword != rePassword:
          return userPassword(request, EffigyCommunication.DANGER, EffigyCommunication.PASSWORD_NOT_MATCH)
        user.set_password(newPassword)
        user.save()
        logout(request)
        return UserLogin(request, EffigyCommunication.SUCCESS, EffigyCommunication.PASSAWORD_EDIT)

      else:
        return userPassword(request, EffigyCommunication.DANGER, EffigyCommunication.USER_NOT_FOUND)

    else:
      return userPassword(request, EffigyCommunication.DANGER, EffigyCommunication.PASSWORD_INVALID)

  return render_to_response(EffigyParameters.USER_PASSWORD,  
    {'description': description , 
    'alert': alert}, context_instance=RequestContext(request))