#-*- coding: utf-8 -*-
from django.contrib.auth.decorators import login_required
from django.conf import settings
from django.contrib.auth import authenticate, login, logout
from django.core.context_processors import csrf
from django.core.files.base import ContentFile
from django.core.files.storage import default_storage
from django.core.mail import send_mail
from django.core.urlresolvers import reverse

from django.db import models
from django.http import HttpResponse, HttpResponseRedirect
from django.shortcuts import render, redirect, render_to_response
from django.template import loader, Context, Template, RequestContext
from django.utils.safestring import mark_safe
from django.utils import translation

from efigie.controller import GoogleAPI
from efigie.controller import EffigyParameters, EffigyCommunication, GoogleAPI


from efigie.models import *

import qrcode
from qrcode.image.pure import PymagingImage

import PIL
from PIL import ImageFont, Image, ImageDraw

import requests
import re
import urllib2
import os

import gettext 
import locale
import os
from efigie.views import *

@login_required
def userAuthenticator(request):
  token, imgQrcode = GoogleAPI.authenticatorGenerate(request.user.username)
  img = qrcode.make(imgQrcode)
  response = HttpResponse(content_type="image/png")
  img.save(response, "PNG")

  imageBase64 = response.getvalue().encode("base64")
  response.close()

  return render_to_response(EffigyParameters.USER_AUTHENTICATOR, 
    {'image': imageBase64,
    'token': token}, context_instance=RequestContext(request))