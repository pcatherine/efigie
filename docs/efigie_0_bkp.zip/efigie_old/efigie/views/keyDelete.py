#!/usr/bin/python
#-*- coding: utf-8 -*-
#OKAY
__author__ = "Paolla Catherine"
__copyright__ = "Copyright 2015-2016, Efigie"
__credits__ = ["Paolla Catherine"]
__version__ = "1.0.0"
__email__ = "paollacath@gmail.com"
__status__ = "Production"

from django.contrib.auth.decorators import login_required

from efigie.controller import EffigyParameters, EffigyCommunication
from efigie.models import UserEfigie, Message, Key, Friend
from efigie.views import *

@login_required
def keyDelete(request, keyId):
  keyName = None
  try:
    key = Key.objects.get(id = keyId)
    keyName = key
    key.delete()
    return keyList(request, EffigyParameters.ALERT_SUCCESS, EffigyCommunication.KEY+"<b>"+ keyName.identifier + "</b>"+ EffigyCommunication.KEY_DELETE)
  except Exception, e:
    return keyList(request, EffigyParameters.ALERT_DANGER, EffigyCommunication.KEY+"<b>"+ keyName.identifier + "</b>"+ EffigyCommunication.KEY_NOT_DELETE)