#!/usr/bin/python
#-*- coding: utf-8 -*-

__author__ = "Paolla Catherine"
__copyright__ = "Copyright 2015-2016, Efigie"
__credits__ = ["Paolla Catherine"]
__version__ = "1.0.0"
__maintainer__ = "Paolla Catherine"
__email__ = "paollacath@gmail.com"
__status__ = "Production"

from django.contrib.auth.decorators import login_required
from django.contrib.auth import logout
from django.shortcuts import render, redirect, render_to_response

from efigie.controller import EffigyParameters, EffigyCommunication
from efigie.models import UserEfigie, Message, Key, Friend
from efigie.views import *

#CATHERINE verificar direito as coisas
@login_required
def userDelete(request):
  try:
    key = Key.objects.get(user = request.user)
  except:
    key = None

  if key is not None:
    key.delete()

  userEfigie = UserEfigie.objects.get(user = request.user)
  if userEfigie is not None:
    userEfigie.delete()
  else:
    return render_to_response(EffigyParameters.USER_SETTINGS, 
      {'alert': 'dange',  
      'description': EffigyCommunication.USER_NOT_DELETE}, context_instance=RequestContext(request))

  user = User.objects.get(username = request.user.username)
  if user is not None:
    user.delete()
  else:
    return render_to_response(EffigyParameters.USER_SETTINGS, 
      {'alert': 'dange',  
      'description': EffigyCommunication.USER_NOT_DELETE}, context_instance=RequestContext(request))
  
  logout(request)
  return efigie.views.userLogin(request, EffigyParameters.ALERT_SUCCESS, EffigyCommunication.USER_DELETE) 