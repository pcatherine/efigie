#-*- coding: utf-8 -*-
from django.contrib.auth.decorators import login_required
from django.core.files.base import ContentFile
from django.core.files.storage import default_storage
from django.http import HttpResponse, HttpResponseRedirect
from django.shortcuts import render, redirect, render_to_response
from django.template import loader, Context, Template, RequestContext

from efigie.controller import EffigyParameters, EffigyCommunication
from efigie.models import UserEfigie, Message, Key, Friend
from efigie.views import *

@login_required
def keyImport(request):
  if request.method == 'POST':
    importKey = request.FILES.get('importKey', '')
    try:
      path = default_storage.save('tmp/key.key', ContentFile(importKey.read()))
      fileKey = open(path, "r")
      lines = fileKey.read()
      
      privateKey = ''
      for i in xrange(len(lines)):
        privateKey += ''.join(list(lines)[i-1:i])
        if len(privateKey) > 29:
          if ''.join(list(privateKey)[i-29:]) == '-----END RSA PRIVATE KEY-----':
            lines = ''.join(list(lines)[i:])

      publicKey = ''
      for i in xrange(len(lines)):
        publicKey += ''.join(list(lines)[i-1:i])
        if len(publicKey) > 24:
          if ''.join(list(publicKey)[i-24:]) == '-----END PUBLIC KEY-----':
            lines = ''.join(list(lines)[i:])

      identifier = ''
      for i in xrange(len(lines)):
        identifier += ''.join(list(lines)[i-1:i])
        if len(identifier) > 33:
          if ''.join(list(identifier)[i-33:]) == '-----END IDENTIFIER SIZE KEY-----':
            lines = ''.join(list(lines)[i:])

            identifier = identifier[19:-33]

            try: 
              keyVerify = Key.objects.get(identifier=identifier)
              count = 0
              if keyVerify.privateKey != privateKey and keyVerify.publicKey != publicKey:
                while True:  
                  identifier += '_' + count
                  keyVerify = Key.objects.get(identifier=identifier)
              else:
                return render_to_response(EffigyParameters.KEY_IMPORT,  
                  {'description': EffigyCommunication.IDENTIFIER_EXIST, 
                  'alert': EffigyParameters.ALTER_DANGER}, context_instance=RequestContext(request))

            except Key.DoesNotExist:
              key = Key.objects.create(user = request.user, identifier = identifier, size = lines, privateKey = privateKey, publicKey = publicKey)
              key.save()
              return keyList(request, EffigyParameters.ALTER_SUCCESS, EffigyCommunication.KEY_IMPORT)

    except Exception, e:
      return keyList(request, EffigyParameters.ALTER_DANGER, EffigyCommunication.KEY_NOT_IMPORT)

  return render(request, EffigyParameters.KEY_IMPORT)