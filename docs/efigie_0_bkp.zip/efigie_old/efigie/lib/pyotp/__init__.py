from efigie.lib.pyotp.otp import OTP
from efigie.lib.pyotp.hotp import HOTP
from efigie.lib.pyotp.totp import TOTP
import efigie.lib.pyotp.utils

import base64
import random


VERSION = '1.3.0'


def random_base32(length=16, random=random.SystemRandom(),
                  chars=base64._b32alphabet.values()):
    return ''.join(
      random.choice(chars)
      for i in xrange(length)
    )
