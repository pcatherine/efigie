# Static Dir

This directory for all static files