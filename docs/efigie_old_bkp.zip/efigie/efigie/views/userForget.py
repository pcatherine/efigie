#-*- coding: utf-8 -*-
from django.contrib.auth.decorators import login_required
from django.conf import settings
from django.contrib.auth import authenticate, login, logout
from django.core.context_processors import csrf
from django.core.files.base import ContentFile
from django.core.files.storage import default_storage
from django.core.mail import send_mail
from django.core.urlresolvers import reverse

from django.db import models
from django.http import HttpResponse, HttpResponseRedirect
from django.shortcuts import render, redirect, render_to_response
from django.template import loader, Context, Template, RequestContext
from django.utils.safestring import mark_safe
from django.utils import translation


# from efigie.controller.Encryption import RSA
# from efigie.controller.Util import *
from efigie.controller import EffigyParameters, EffigyCommunication, GoogleAPI


from efigie.models import *

import qrcode
from qrcode.image.pure import PymagingImage

import PIL
from PIL import ImageFont, Image, ImageDraw

import requests
import re
import urllib2
import os

import gettext 
import locale
import os
from efigie.views import *

# CATHERINE
def userForget(request):
  if request.method == 'POST':
    username  = request.POST.get('username', '')

    if '@' in username:
      try: 
        user = User.objects.get(email=username)

        some_model_instance = userEfigie
        EmailConfirmation.objects.verify_email_for_object(
            email=email,
            content_object=some_model_instance,
            email_field_name='customer_forget_email'
        )

        # send_mail('Efigie - Esqueci minha senha', 'Here is the message.', 'noreplay@efigie.com',
          # [user.email], fail_silently=False)
      except:
        return render_to_response(EffigyParameters.USER_FORGET, 
          {'description': EffigyCommunication.USER_NOT_FOUND, 
          'alert': 'danger',
          'username' : username }, context_instance=RequestContext(request))
    
    else:
      try: 
        user = User.objects.get(username=username)
        
        some_model_instance = userEfigie
        EmailConfirmation.objects.verify_email_for_object(
            email=email,
            content_object=some_model_instance,
            email_field_name='customer_forget_email'
        )

        # send_mail('Subject here', 'Here is the message.', 'noreplay@efigie.com', [user.email], fail_silently=False)
      except:
        return render_to_response(EffigyParameters.USER_FORGET, 
          {'description': EffigyCommunication.USER_NOT_FOUND, 
          'alert': 'danger',
          'username' : username }, context_instance=RequestContext(request))
    return userLogin(request, EffigyCommunication.SUCCESS, EffigyCommunication.FORGET_PASSWORD)

  return render(request, EffigyParameters.USER_FORGET)