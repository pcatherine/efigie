#-*- coding: utf-8 -*-
from django.contrib.auth.decorators import login_required
from django.db import models
from django.http import HttpResponse, HttpResponseRedirect
from django.shortcuts import render, redirect, render_to_response
from django.template import loader, Context, Template, RequestContext
from django.utils.safestring import mark_safe

from django.core.servers.basehttp import FileWrapper

from efigie.models import UserEfigie, Message, Key, Friend
from efigie.controller import EffigyParameters, EffigyCommunication
import efigie.config
import json
from efigie.views import *

@login_required
def messageWrite(request):
  if request.method == 'POST':
    message = request.POST.get('message', '')
    image   = request.FILES.get('image', '')
    count   = request.POST.get('count', '')
    
    if count != '':
      try:
        if int(count) <= 0:
          return render_to_response(EffigyParameters.MESSAGE_WRITE, 
            {'description': EffigyCommunication.MESSAGE_BLANK_SIZE, 
            'alert': 'danger',
            'message' : message,
            'count': count}, context_instance=RequestContext(request))
      except:
        return render_to_response(EffigyParameters.MESSAGE_WRITE, 
          {'description': EffigyCommunication.MESSAGE_BLANK_SIZE, 
          'alert': 'danger',
          'message' : message,
          'count': count}, context_instance=RequestContext(request))
    
    descriptionErr = ''
    inputEmpty = []

    if message == '':
      return render_to_response(EffigyParameters.MESSAGE_WRITE, 
        {'description': EffigyCommunication.MESSAGE_BLANK, 
        'alert': 'danger'}, context_instance=RequestContext(request))


    if len(inputEmpty) == 1:
      descriptionErr += inputEmpty[0] 
      descriptionErr += EffigyCommunication.IS_BLANK + EffigyCommunication.SPACE

    elif len(inputEmpty) > 1:
      descriptionErr += inputEmpty[0] 
      descriptionErr += EffigyCommunication.AND + EffigyCommunication.SPACE
      descriptionErr += inputEmpty[1]
      descriptionErr += EffigyCommunication.ARE_BLANK 

      if descriptionErr != '':
        return render_to_response(EffigyParameters.MESSAGE_WRITE, 
          {'description': descriptionErr, 
          'alert': 'danger',
          'message' : message,
          'count': count}, context_instance=RequestContext(request))

    request.session['msgText'] = message
    request.session['msgCount'] = count
    if 'msgWrite' in request.session :
      del request.session['msgWrite']
    
    if image  == '':
      return imageSearch(request, 'info', EffigyCommunication.MESSAGE_SEARCH)

    userEfigie = UserEfigie.objects.get(user = request.user)
    
    return messageSet(request, image)
  return render(request, EffigyParameters.MESSAGE_WRITE)