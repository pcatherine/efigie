#!/usr/bin/python
#-*- coding: utf-8 -*-

__author__ = "Paolla Catherine"
__copyright__ = "Copyright 2015-2016, Efigie"
__credits__ = ["Paolla Catherine"]
__version__ = "1.0.0"
__email__ = "paollacath@gmail.com"
__status__ = "Production"

from efigie.views.imageSearch import *

from efigie.views.index import *

from efigie.views.keyList import *

from efigie.views.keyDelete import *
from efigie.views.keyEdit import *
from efigie.views.keyExport import *
from efigie.views.keyImport import *
from efigie.views.keyNew import *
from efigie.views.keyShow import *

from efigie.views.messageRead import *
from efigie.views.messageSet import *
from efigie.views.messageSettings import *
from efigie.views.messageWrite import *

from efigie.views.messageRead import *
from efigie.views.messageSet import *
from efigie.views.messageSettings import *
from efigie.views.messageWrite import *

from efigie.views.userAuthenticator import *
from efigie.views.userDelete import *
from efigie.views.userEdit import *
from efigie.views.userForgetPassword import *
from efigie.views.userLogin import *
from efigie.views.userLoginAuthenticator import *
from efigie.views.userLogout import *
from efigie.views.userNew import *
from efigie.views.userPassword import *
from efigie.views.userSettings import *

from efigie.views.userEmailConfirmation import *