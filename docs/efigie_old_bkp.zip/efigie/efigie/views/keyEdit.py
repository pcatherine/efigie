#!/usr/bin/python
#-*- coding: utf-8 -*-
#OKAY
__author__ = "Paolla Catherine"
__copyright__ = "Copyright 2015-2016, Efigie"
__credits__ = ["Paolla Catherine"]
__version__ = "1.0.0"
__email__ = "paollacath@gmail.com"
__status__ = "Production"

from django.contrib.auth.decorators import login_required
from django.shortcuts import render, redirect, render_to_response
from django.template import loader, Context, Template, RequestContext

from efigie.controller import EffigyParameters, EffigyCommunication, Encryption
from efigie.models import UserEfigie, Message, Key, Friend
from efigie.views import *

@login_required
def keyEdit(request, keyId):
  if request.method == 'POST':
    sizeKey   = request.POST.get('key', '')
    identifier = request.POST.get('identifier', '')

    if (sizeKey == '' ):
      return render_to_response(EffigyParameters.KEY_EDIT,  
        {'description': EffigyCommunication.KEY_BLANK_SIZE, 
        'alert': EffigyParameters.ALTER_DANGER,
        'identifier': identifier}, context_instance=RequestContext(request))

    else:
      privateKey, publicKey = Encryption.RSA.generate(int(sizeKey))
      try:
        key = key.objects.get(identifier=identifier)
        if keyId != key.id:
          return render_to_response(EffigyParameters.KEY_EDIT,
            {'description': EffigyCommunication.IDENTIFIER_EXIST, 
            'alert': EffigyParameters.ALTER_DANGER,
            'identifier': identifier}, context_instance=RequestContext(request))
      except:
        key = Key.objects.get(id = keyId)
        key.identifier = (key.identifier, identifier) [identifier != '']
        key.size = sizeKey
        key.privateKey = privateKey
        key.publicKey = publicKey
        key.save()
        return keyList(request, EffigyParameters.ALERT_SUCCESS, EffigyCommunication.KEY_EDIT)
        
  try:
    key = Key.objects.get(id = keyId)
    return render_to_response(EffigyParameters.KEY_EDIT,  
      {'key': key}, context_instance=RequestContext(request))
  except:
    return keyList(request, EffigyParameters.ALTER_DANGER, EffigyCommunication.KEY_NOT_FOUND)